wandex
======

wandex is a fork of Wand_ project, with added MagickWand API
methods, like blur, sharpen and resample.

Beware that this code is not tested, so use it at your own risks.

You can install the package from PyPI_ by using ``pip``:

.. code-block:: console

   $ pip install wandex

.. _Wand: http://wand-py.org/
.. _PyPI: https://pypi.python.org/pypi/Wand
