"""
This module contains transformation functions (clip->clip)
One file for one fx. The file's name is the fx's name
"""
